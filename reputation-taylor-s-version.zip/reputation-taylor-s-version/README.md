# REPUTATION (TAYLOR´S VERSION)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Augus-the-reactor/pen/MYgbomx](https://codepen.io/Augus-the-reactor/pen/MYgbomx).

